// JavaScript source code
// Script to open and close sidebar
//function open() {
//    document.getElementById("mySidebar").style.display = "block";
//    document.getElementById("myOverlay").style.display = "block";
//}

//function close() {
//    document.getElementById("mySidebar").style.display = "none";
//    document.getElementById("myOverlay").style.display = "none";
//}

//// Modal Image Gallery
//function onClick(element) {
//    document.getElementById("img01").src = element.src;
//    document.getElementById("modal01").style.display = "block";
//    var captionText = document.getElementById("caption");
//    captionText.innerHTML = element.alt;
//}

//var myIndex = 0;
//carousel();
//function carousel() {
//    var i;
//    var x = document.getElementsByClassName("mySlides");
//    for (i = 0; i < x.length; i++) {
//        x[i].style.display = "none";
//    }
//    myIndex++;
//    if (myIndex > x.length) { myIndex = 1 }
//    x[myIndex - 1].style.display = "block";
//    setTimeout(carousel, 3000); // Change image every 3 seconds
//}

//Manual Slideshow
var slideIndex = 1;
showDivs(slideIndex);

function plusDivs(n) {
    showDivs(slideIndex += n);
}

function currentDiv(n) {
    showDivs(slideIndex = n);
}

function showDivs(n) {
    var i;
    var x = document.getElementsByClassName("mySlides");
    var dots = document.getElementsByClassName("demo");
    if (n > x.length) { slideIndex = 1 }
    if (n < 1) { slideIndex = x.length }
    for (i = 0; i < x.length; i++) {
        x[i].style.display = "none";
    }
    for (i = 0; i < dots.length; i++) {
        dots[i].className = dots[i].className.replace(" w3-white", "");
    }
    x[slideIndex - 1].style.display = "block";
    dots[slideIndex - 1].className += " w3-white";
}


//try
	
//BACK TO TOP BUTTON

// When the user scrolls down 20px from the top of the document, show the button
window.onscroll = function() {scrollFunction()};
function scrollFunction() {
    if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {
        document.getElementById("myBtn").style.display = "block";
    } else {
        document.getElementById("myBtn").style.display = "none";
    }
}

// When the user clicks on the button, scroll to the top of the document
function topFunction() {
    document.body.scrollTop = 0;
    document.documentElement.scrollTop = 0;
}	

