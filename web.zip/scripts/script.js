

    $("#mn").click(function(){
        $("#mission").fadeToggle("slow");
    });
    $("#vn").click(function(){
        $("#vision").fadeToggle("slow");
    });